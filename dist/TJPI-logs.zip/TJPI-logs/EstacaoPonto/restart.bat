taskkill /f /im EstacaoPonto.exe
cd "null"
start /b EstacaoPonto.exe
exit 0
